<?php

// Default Wordpress functions
include ("functions/functions-defaults.php");

?>