<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content
 * after.  Calls sidebar-footer.php for bottom widgets.
 *
 * @package WordPress
 * @subpackage Default Responsive Theme
 * @by Ebow - 1.0
 */
?>

</section><!-- #main -->
<footer role="contentinfo">

</footer><!-- footer -->

<?php wp_footer();?>
</body>
</html>