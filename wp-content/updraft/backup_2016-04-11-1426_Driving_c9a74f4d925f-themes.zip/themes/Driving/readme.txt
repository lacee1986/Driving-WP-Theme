/*
==========================================================================
=== Theme: Driving Theme
=== By: Laszlo Kruchio
=== Version: 1.0
========================================================================== 
*/

Must Have Plugins:
	- Advanced Custom Fields Pro: Download from Google Drive
	- Google Analytics: http://wordpress.org/plugins/google-analytics-for-wordpress/
	- Google XML Sitemaps: http://wordpress.org/plugins/google-sitemap-generator/
	- SEO Plugin by Yoast: https://wordpress.org/plugins/wordpress-seo/
	
	
Slider: http://kenwheeler.github.io/slick/
Custom Checkboxes / Radio Buttons: http://www.csscheckbox.com/radio-buttons.php
Dashicons: http://melchoyce.github.io/dashicons/

Included Javascript files: 
	- Ajax login: Create easy ajax login, check the functions file
	- Google map: Integrate Google Maps
	- Isotope: Masonry style list with filters
	- Validate: Form validations



